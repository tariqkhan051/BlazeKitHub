module.exports = {
    "env": {
        "browser": true,
        "es2021": true,
        "node": true
    },
    "root": true,
    "parser": "@typescript-eslint/parser",
    "plugins": [
        "@typescript-eslint",
        "unused-imports"
    ],
    "rules": {
        "unused-imports/no-unused-imports": "error",
        "indent": ["error", 4],
        "no-empty-pattern": "error",
        "semi": [
            "error",
            "always"
        ],
        "semi-style": [
            "error",
            "last"
        ],
        "no-extra-semi": "error",
        "no-const-assign": "error",
        "eqeqeq": "error",
        "func-style": "error",
        "require-await": "error",
        "space-before-blocks": [
            "warn",
            "always"
        ],
        "no-multi-spaces": "warn",
        "newline-per-chained-call": "error",
        "func-call-spacing": [
            "warn",
            "never"
        ],
        "no-template-curly-in-string": "warn",
        "no-constant-condition": "error",
        "no-dupe-args": "error",
        "no-dupe-keys": "error",
        "no-duplicate-imports": "error",
        "no-dupe-class-members": "error",
        "no-fallthrough": "error",
        "no-unreachable": "error",
        "no-unsafe-optional-chaining": "error",
        "no-unused-expressions": "error",
        "@typescript-eslint/no-unused-vars": "warn",
        "@typescript-eslint/no-explicit-any": "warn",
        "curly": "error",
        "use-isnan": "warn",
        "no-else-return": [
            "error",
            {
                "allowElseIf": false
            }
        ],
        "no-lonely-if": "error",
        "@typescript-eslint/no-magic-numbers": [
            "warn",
            {
                "ignoreArrayIndexes": true,
                "ignoreDefaultValues": true,
                "ignoreEnums": true,
                "ignore": [
                    0,
                    1
                ]
            }
        ],
        "prefer-const": "error",
        "prefer-template": "warn",
        "block-spacing": "warn",
        "arrow-spacing": "warn",
        "comma-dangle": [
            "error",
            "never"
        ],
        "comma-spacing": [
            "warn",
            {
                "before": false,
                "after": true
            }
        ],
        "comma-style": [
            "warn",
            "last"
        ],
        "computed-property-spacing": [
            "warn",
            "never"
        ],
        "no-multiple-empty-lines": [
            "error",
            {
                "max": 0,
                "maxEOF": 0
            }
        ],
        "no-trailing-spaces": "warn",
        "quotes": [
            "warn",
            "double",
            {
                "avoidEscape": true
            }
        ],
        "no-var": "warn"
    }
}